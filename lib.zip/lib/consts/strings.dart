const appname = "My-Daraz";
const appversion = "Version 1.0.1";
const credits = " @Ahmad Irtza";
const email = "Email";
const emailhint = "Email";
const password = "Password";
const passwordHint = "********";
const reTypePassword = "Re-type Password";
const name = "Name";
const nameHint = "Name";
const login = "Log In";
const signup = "Sign Up";
const forgetPassword = "Forget Password?";
const createNewAccount = "Create new Account";
const loginWith = " Login With";
const termsAndCond = " Terms & Conditions";
const privacyPolicy = "Privacy Policy";
const alreadyHaveAccount = "Already Have an Account?";

//Home
const home = "Home";
const categories = "Categories";
const cart = "Cart";
const account = "Account";

//Home Screen
const searchAnything = "Search anything...",
    topCategories = "Top Categories",
    todayDeal = "Today Deal",
    brands = "Brands",
    flashSale = "Flash Sale",
    topSellers = "Top Sellers",
    featureCategories = "Feature Categories",
    womenDress = "Women Dresses",
    girlsDress = "Girls Dress",
    boysGlasses = "Boys Glasses",
    mobilePhones = "Mobile Phones",
    tShirts = "T-Shirts",
    girlsWatches = "Girls Watches";

const featureProduct = "Feature Product";

//categories
const womenClothing = "Women Dresses",
    menClothing = "Men Dresses",
    automobile = "Automobiles",
    compAccessories = "Computer & Accessories",
    kidToys = "Kids & Toys",
    sports = "Sports",
    jewellery = "Jewellery",
    phone = "Mobiles & Tablets",
    furniture = "Furniture";

const addToCart = "Add to Cart";
const logout = "Logout";

//Items

const video = "Video",
    reviews = "Reviews",
    sellerPolicy = "Seller Policy",
    returnPolicy = "Return Policy",
    supportPolicy = "Support Policy",
    productsLike = "Products you make Like";

const wishList = "My Wishlist", orders = "My Orders", messages = "Messages";
